Telegram static sticker pack

Contains 11 original artworks prepared as 512 x 512 transparent PNGs and lossless WEBPs.
The source illustrations were not redrawn; only their outer connected gray/dark backdrops were made transparent.
thin-floor-caution and thin-floor-fall were separated from one combined source image.
